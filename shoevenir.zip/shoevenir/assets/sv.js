( function () {
	const cfg = window.SV || {};
	const freeAt = Number( cfg.freeAt ) || 10000;
	const fmt = ( n ) => 'KSh ' + Math.round( n ).toLocaleString( 'en-US' );
	const $$ = ( sel, root = document ) => Array.from( root.querySelectorAll( sel ) );
	const esc = ( s ) => String( s ).replace( /[&<>"']/g, ( c ) => ( { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } )[ c ] );
	// Store API names come HTML-encoded (e.g. &#8211;); turn them back into plain text.
	const plain = ( s ) => new DOMParser().parseFromString( String( s ), 'text/html' ).documentElement.textContent;
	const money = ( minor, prices ) => Number( minor ) / Math.pow( 10, ( prices && prices.currency_minor_unit ) || 0 );
	const heart = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.3 4.6 13a4.8 4.8 0 0 1 6.8-6.8l.6.6.6-.6a4.8 4.8 0 0 1 6.8 6.8Z"/></svg>';
	const waUrl = ( text ) => 'https://wa.me/' + cfg.wa + '?text=' + encodeURIComponent( text );

	/* Toasts ------------------------------------------------------------ */
	function toast( msg, img ) {
		let box = document.querySelector( '.sv-toasts' );
		if ( ! box ) {
			box = document.createElement( 'div' );
			box.className = 'sv-toasts';
			box.setAttribute( 'role', 'status' );
			box.setAttribute( 'aria-live', 'polite' );
			document.body.appendChild( box );
		}
		const t = document.createElement( 'div' );
		t.className = 'sv-toast';
		t.innerHTML = ( img ? '<img src="' + esc( img ) + '" alt="">' : '<i>✓</i>' ) + '<span>' + msg + '</span>';
		box.appendChild( t );
		setTimeout( () => t.classList.add( 'is-out' ), 3400 );
		setTimeout( () => t.remove(), 3900 );
	}
	// Product-page adds (classic form) end in a toast too.
	if ( window.jQuery ) window.jQuery( document.body ).on( 'added_to_cart', () => toast( 'Added to your cart' ) );
	// Promo codes: WooCommerce shows its own notice; add a toast so it isn't missed.
	document.addEventListener( 'click', ( e ) => {
		if ( ! e.target.closest( '.wc-block-components-totals-coupon__button' ) ) return;
		setTimeout( () => {
			const err = document.querySelector( '.wc-block-components-totals-coupon .wc-block-components-validation-error' );
			if ( err ) toast( esc( err.textContent ) );
			else if ( document.querySelector( '.wc-block-components-totals-discount' ) ) toast( 'Promo code applied 🎉' );
		}, 1500 );
	} );

	/* Store API ---------------------------------------------------------- */
	let nonce = '';
	async function getCart() {
		const res = await fetch( cfg.store + 'cart', { credentials: 'same-origin' } );
		nonce = res.headers.get( 'Nonce' ) || nonce;
		return res.json();
	}
	// The header mini cart keeps its own copy of the cart (Interactivity API, or wp.data on
	// older WooCommerce); tell whichever is on the page to reload it.
	async function refreshMiniCart( cart ) {
		try {
			const { store } = await import( '@wordpress/interactivity' );
			const wc = store( 'woocommerce' );
			if ( wc && wc.actions && wc.actions.refreshCartItems ) await wc.actions.refreshCartItems();
		} catch ( e ) {}
		const data = window.wp && window.wp.data;
		if ( cart && data && data.dispatch( 'wc/store/cart' ) && data.dispatch( 'wc/store/cart' ).receiveCart ) {
			data.dispatch( 'wc/store/cart' ).receiveCart( cart );
		}
		if ( cart && cart.totals ) renderBar( money( cart.totals.total_items, cart.totals ) );
	}

	// id is the product, or the chosen pair's variation id.
	async function addToCart( id, btn ) {
		if ( btn ) btn.disabled = true;
		try {
			if ( ! nonce ) await getCart();
			const res = await fetch( cfg.store + 'cart/add-item', {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/json', Nonce: nonce },
				body: JSON.stringify( { id: Number( id ), quantity: 1 } ),
			} );
			const cart = await res.json();
			if ( ! res.ok ) {
				// Each pair is one of one, so a second add is refused: say so plainly.
				const already = /cannot add another|already|not enough stock/i.test( cart.message || '' );
				throw new Error( already ? 'That pair is already in your cart – it\'s one of one.' : plain( cart.message || 'Could not add' ) );
			}
			await refreshMiniCart( cart );
			const item = ( cart.items || [] ).find( ( it ) => it.id === Number( id ) );
			toast( '<strong>' + esc( item ? plain( item.name ) : 'Pair' ) + '</strong> added to your cart', item && item.images && item.images[ 0 ] ? item.images[ 0 ].thumbnail : '' );
			// The mini cart opens its drawer on this event.
			document.body.dispatchEvent( new CustomEvent( 'wc-blocks_added_to_cart', { bubbles: true } ) );
			// The drawer can briefly re-show an older copy while it opens; refresh once more after.
			setTimeout( () => refreshMiniCart(), 900 );
		} catch ( e ) {
			toast( esc( e.message || 'Could not add to your cart. Please try again.' ) );
		} finally {
			if ( btn ) btn.disabled = false;
		}
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-sv-add]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		addToCart( b.dataset.svAdd, b );
	} );

	/* WhatsApp orders ---------------------------------------------------- */
	const itemLine = ( it ) => {
		const opts = ( it.variation || [] ).map( ( v ) => plain( v.value ) ).join( ', ' );
		const sv = ( it.extensions && it.extensions.sv ) || {};
		const facts = [ opts || sv.size, sv.grade ].filter( Boolean ).join( ', ' );
		return '• ' + plain( it.name ) + ( facts ? ' (' + facts + ')' : '' ) + ' – ' + fmt( money( it.totals.line_total, it.totals ) );
	};
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-sv-wa-cart]' );
		if ( ! b ) return;
		e.preventDefault();
		// Open the tab now (inside the click) so pop-up blockers allow it, then fill in the link.
		const win = window.open( '', '_blank' );
		try {
			const cart = await getCart();
			if ( ! cart.items || ! cart.items.length ) {
				if ( win ) win.close();
				toast( 'Your cart is empty.' );
				return;
			}
			const lines = [ 'Hi Shoevenir, I\'d like to order:' ];
			cart.items.forEach( ( it ) => lines.push( itemLine( it ) ) );
			lines.push( 'Subtotal: ' + fmt( money( cart.totals.total_items, cart.totals ) ) );
			( cart.coupons || [] ).forEach( ( c ) => lines.push( 'Promo code: ' + c.code.toUpperCase() ) );
			lines.push( 'Deliver to: ' );
			lines.push( 'Payment (M-Pesa / cash on delivery / pick-up): ' );
			const url = waUrl( lines.join( '\n' ) );
			if ( win ) win.location = url;
			else window.location = url;
		} catch ( err ) {
			if ( win ) win.close();
			toast( 'Could not read your cart. Please try again.' );
		}
	} );

	/* Product page: pair picker ----------------------------------------- */
	// Multi-pair listings: WooCommerce's "Pair" dropdown becomes buttons (the dropdown stays in the
	// form, hidden, so WooCommerce still swaps the price and stock). Sold pairs are struck through.
	function initPairs() {
		$$( 'form.variations_form select[name^="attribute_"]' ).forEach( ( sel ) => {
			if ( sel.dataset.svSw ) return;
			sel.dataset.svSw = '1';
			const form = sel.closest( 'form' );
			let vars = [];
			try {
				vars = JSON.parse( form.dataset.product_variations || '[]' ) || [];
			} catch ( e ) {}
			const sold = ( val ) => vars.some( ( v ) => Object.values( v.attributes || {} ).includes( val ) && ! v.is_in_stock );
			const wrap = document.createElement( 'div' );
			wrap.className = 'sv-sw';
			wrap.setAttribute( 'role', 'radiogroup' );
			const opts = Array.from( sel.options ).filter( ( o ) => o.value );
			wrap.innerHTML = opts.map( ( o ) => '<button type="button" role="radio" aria-checked="false" data-v="' + esc( o.value ) + '"' + ( sold( o.value ) ? ' class="is-sold" title="Sold"' : '' ) + '>' + esc( o.text ) + '</button>' ).join( '' );
			sel.after( wrap );
			sel.classList.add( 'sv-sw-select' );
			const paint = () => $$( 'button', wrap ).forEach( ( b ) => {
				const on = b.dataset.v === sel.value;
				b.classList.toggle( 'is-on', on );
				b.setAttribute( 'aria-checked', on ? 'true' : 'false' );
			} );
			wrap.addEventListener( 'click', ( e ) => {
				const b = e.target.closest( 'button' );
				if ( ! b ) return;
				sel.value = b.dataset.v;
				sel.dispatchEvent( new Event( 'change', { bubbles: true } ) );
				if ( window.jQuery ) window.jQuery( sel ).trigger( 'change' );
				paint();
				updateWaProduct( form );
			} );
			paint();
			updateWaProduct( form );
		} );
		// Hide WooCommerce's "Clear" link: a pair is always chosen.
		$$( 'form.variations_form .reset_variations' ).forEach( ( a ) => ( a.hidden = true ) );
	}
	// The product page's WhatsApp button names the pair the customer picked.
	function updateWaProduct( form ) {
		const a = document.querySelector( '[data-sv-wa-product]' );
		if ( ! a || ! form ) return;
		const picked = $$( 'select[name^="attribute_"]', form ).map( ( s ) => s.value ).filter( Boolean ).join( ', ' );
		a.href = waUrl( 'Hi Shoevenir, is the ' + a.dataset.svWaProduct + ' (' + ( picked || a.dataset.svWaSize ) + ', ' + a.dataset.svWaPrice + ') still available? ' + a.dataset.svWaUrl );
	}
	// "Size guide" link above the button opens the size tab.
	document.addEventListener( 'click', ( e ) => {
		const a = e.target.closest( '[data-sv-tab]' );
		if ( ! a ) return;
		const tab = document.querySelector( '#tab-title-' + a.dataset.svTab + ' a' );
		if ( ! tab ) return;
		e.preventDefault();
		tab.click();
		tab.scrollIntoView( { behavior: 'smooth', block: 'center' } );
	} );

	/* Saved pairs -------------------------------------------------------- */
	const KEY = 'sv-wishlist';
	const readWish = () => {
		try {
			return JSON.parse( localStorage.getItem( KEY ) || '[]' ).map( Number ).filter( Boolean );
		} catch ( e ) {
			return [];
		}
	};
	const writeWish = ( ids ) => {
		try {
			localStorage.setItem( KEY, JSON.stringify( ids ) );
		} catch ( e ) {}
	};
	function paintWish() {
		const ids = readWish();
		// Only touch the DOM when something changed: the MutationObserver below calls this.
		$$( '[data-sv-wish]' ).forEach( ( b ) => {
			const on = ids.includes( Number( b.dataset.svWish ) );
			if ( b.classList.contains( 'is-on' ) === on ) return;
			b.classList.toggle( 'is-on', on );
			b.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
		} );
		$$( '[data-sv-wish-count]' ).forEach( ( el ) => {
			if ( el.textContent !== String( ids.length ) ) el.textContent = ids.length;
			el.hidden = ids.length === 0;
		} );
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-sv-wish]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const id = Number( b.dataset.svWish );
		let ids = readWish();
		const on = ids.includes( id );
		ids = on ? ids.filter( ( x ) => x !== id ) : [ ...ids, id ];
		writeWish( ids );
		paintWish();
		toast( on ? 'Removed from your wishlist' : '♥ Saved to <a href="' + esc( cfg.home || '/' ) + 'wishlist/">your wishlist</a>' );
		if ( b.closest( '[data-sv-wishlist]' ) ) renderWishlist();
	} );

	// Add button for a product: multi-pair listings need a pair first, so they link to the product.
	const buyButton = ( p ) => {
		if ( ! p.is_purchasable || ! p.is_in_stock ) return '<a class="wp-element-button sv-btn-ghost" href="' + esc( p.permalink ) + '">Sold · view</a>';
		if ( p.type === 'variable' ) return '<a class="wp-element-button" href="' + esc( p.permalink ) + '">Choose your pair</a>';
		return '<button type="button" class="wp-element-button" data-sv-add="' + p.id + '">Add to cart</button>';
	};

	async function renderWishlist() {
		const box = document.querySelector( '[data-sv-wishlist]' );
		if ( ! box ) return;
		const ids = readWish();
		if ( ! ids.length ) {
			box.innerHTML = '<div class="sv-empty-wish"><p>Nothing saved yet. Tap the ♥ on any pair to keep it here.</p><a class="wp-element-button" href="' + esc( cfg.shop || '/shop/' ) + '">Browse the drops</a></div>';
			return;
		}
		try {
			const res = await fetch( cfg.store + 'products?include=' + ids.join( ',' ) + '&per_page=50' );
			const items = await res.json();
			box.innerHTML = '<div class="sv-wish-grid">' + items.map( ( p ) => {
				const img = p.images && p.images[ 0 ] ? '<img src="' + esc( p.images[ 0 ].thumbnail || p.images[ 0 ].src ) + '" alt="" loading="lazy">' : '';
				const sv = ( p.extensions && p.extensions.sv ) || {};
				return '<article class="sv-wish-card"><a href="' + esc( p.permalink ) + '">' + img + '</a>' +
					'<button type="button" class="sv-heart is-on" data-sv-wish="' + p.id + '" aria-label="Remove from wishlist" aria-pressed="true">' + heart + '</button>' +
					'<h3><a href="' + esc( p.permalink ) + '">' + p.name + '</a></h3><p class="sv-small">' + esc( sv.size || '' ) + '</p><div class="sv-wish-price">' + p.price_html + '</div>' + buyButton( p ) + '</article>';
			} ).join( '' ) + '</div>';
		} catch ( e ) {
			box.innerHTML = '<p>Could not load your saved pairs. Please refresh the page.</p>';
		}
	}

	/* Quick view --------------------------------------------------------- */
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-sv-qv]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const dlg = document.getElementById( 'sv-qv' );
		const body = dlg && dlg.querySelector( '[data-sv-qv-body]' );
		if ( ! body || ! dlg.showModal ) return;
		body.innerHTML = '<p class="sv-small">Loading…</p>';
		dlg.showModal();
		try {
			const p = await ( await fetch( cfg.store + 'products/' + b.dataset.svQv ) ).json();
			const sv = ( p.extensions && p.extensions.sv ) || {};
			const imgs = ( p.images || [] ).map( ( im, i ) => '<img src="' + esc( im.src ) + '" alt="' + esc( im.alt || plain( p.name ) ) + '"' + ( i ? ' hidden' : '' ) + '>' ).join( '' );
			const thumbs = ( p.images || [] ).length > 1 ? '<div class="sv-qv__thumbs">' + p.images.map( ( im, i ) => '<button type="button" data-sv-qv-img="' + i + '"' + ( i ? '' : ' class="is-on"' ) + '><img src="' + esc( im.thumbnail || im.src ) + '" alt=""></button>' ).join( '' ) + '</div>' : '';
			const brand = p.brands && p.brands[ 0 ] ? p.brands[ 0 ].name : '';
			const attr = ( p.attributes || [] ).find( ( a ) => a.has_variations );
			let choose = '';
			let buy;
			if ( ! p.is_purchasable || ! p.is_in_stock ) {
				buy = '<button type="button" class="wp-element-button" disabled>Sold</button>';
			} else if ( attr && p.variations && p.variations.length ) {
				// One button per pair; each carries its variation id for the cart.
				choose = '<p class="sv-qv__label">' + esc( plain( attr.name ) ) + ': <strong data-sv-qv-picked></strong></p><div class="sv-sw">' + p.variations.map( ( v, i ) => {
					const val = v.attributes && v.attributes[ 0 ] ? v.attributes[ 0 ].value : '';
					const term = ( attr.terms || [] ).find( ( t ) => t.slug === val || t.name === val );
					const label = term ? plain( term.name ) : val;
					return '<button type="button" data-sv-qv-var="' + v.id + '" data-label="' + esc( label ) + '"' + ( i ? '' : ' class="is-on"' ) + '>' + esc( label ) + '</button>';
				} ).join( '' ) + '</div>';
				buy = '<button type="button" class="wp-element-button" data-sv-add="' + p.variations[ 0 ].id + '" data-sv-qv-buy>Add to cart</button>';
			} else {
				buy = '<button type="button" class="wp-element-button" data-sv-add="' + p.id + '">Add to cart</button>';
			}
			const wa = '<a class="sv-wa-order" href="' + esc( waUrl( 'Hi Shoevenir, is the ' + plain( p.name ) + ' (' + ( sv.size || '' ) + ') still available? ' + p.permalink ) ) + '" target="_blank" rel="noopener">Order via WhatsApp</a>';
			body.innerHTML = '<div class="sv-qv__grid"><div class="sv-qv__media"><div class="sv-qv__main">' + imgs + '</div>' + thumbs + '</div>' +
				'<div class="sv-qv__info">' + ( brand ? '<p class="sv-eyebrow">' + esc( plain( brand ) ) + '</p>' : '' ) + '<h2>' + p.name + '</h2>' +
				'<div class="sv-qv__meta">' + ( sv.size ? '<span>' + esc( sv.size ) + '</span>' : '' ) + ( sv.grade ? '<span class="sv-grade sv-grade--' + esc( sv.gradeSlug || '' ) + '">' + esc( sv.grade ) + '</span>' : '' ) + '</div>' +
				'<div class="sv-qv__price">' + p.price_html + '</div>' +
				'<div class="sv-qv__desc">' + ( p.short_description || '' ) + '</div>' + ( sv.condition || '' ) + choose +
				'<div class="sv-qv__actions">' + buy + wa + '<a class="sv-link" href="' + esc( p.permalink ) + '">Full details, size guide &amp; shipping →</a></div></div></div>';
			const first = body.querySelector( '[data-sv-qv-var]' );
			if ( first ) pickQvVariation( first );
		} catch ( err ) {
			body.innerHTML = '<p>Could not load this pair. Please try again.</p>';
		}
	} );
	async function pickQvVariation( btn ) {
		const box = btn.closest( '[data-sv-qv-body]' );
		$$( '[data-sv-qv-var]', box ).forEach( ( b ) => b.classList.toggle( 'is-on', b === btn ) );
		const picked = box.querySelector( '[data-sv-qv-picked]' );
		if ( picked ) picked.textContent = btn.dataset.label;
		const buy = box.querySelector( '[data-sv-qv-buy]' );
		if ( buy ) buy.dataset.svAdd = btn.dataset.svQvVar;
		try {
			const v = await ( await fetch( cfg.store + 'products/' + btn.dataset.svQvVar ) ).json();
			if ( buy ) {
				buy.disabled = ! v.is_in_stock;
				buy.textContent = v.is_in_stock ? 'Add to cart' : 'This pair has sold';
			}
		} catch ( e ) {}
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-sv-qv-var]' );
		if ( b ) pickQvVariation( b );
	} );
	document.addEventListener( 'click', ( e ) => {
		const t = e.target.closest( '[data-sv-qv-img]' );
		if ( ! t ) return;
		const media = t.closest( '.sv-qv__media' );
		media.querySelectorAll( '.sv-qv__main img' ).forEach( ( im, i ) => ( im.hidden = i !== Number( t.dataset.svQvImg ) ) );
		media.querySelectorAll( '[data-sv-qv-img]' ).forEach( ( x ) => x.classList.toggle( 'is-on', x === t ) );
	} );
	document.addEventListener( 'click', ( e ) => {
		if ( e.target.matches( 'dialog.sv-dialog' ) ) e.target.close();
	} );

	/* Instant search ----------------------------------------------------- */
	// "43", "eu 43" or "size 43" searches by size; an empty box offers size and brand shortcuts.
	const sizeQuery = ( q ) => {
		const m = q.toLowerCase().match( /^(?:size\s*|eu\s*)?(\d{2}(?:\.5)?)$/ );
		return m ? ( cfg.sizes || [] ).find( ( s ) => s.name === 'EU ' + m[ 1 ] ) || { name: 'EU ' + m[ 1 ], url: '', n: 0 } : null;
	};
	function quickHtml() {
		const chips = ( list ) => list.map( ( x ) => '<a class="sv-chip sv-chip--sm" href="' + esc( x.url ) + '">' + esc( x.label ) + '</a>' ).join( '' );
		return '<div class="sv-suggest__quick"><p class="sv-mini-label">Quick filter · size</p><div>' + chips( ( cfg.sizes || [] ).map( ( s ) => ( { label: s.name, url: s.url } ) ) ) + '</div><p class="sv-mini-label">Brand</p><div>' + chips( ( cfg.brands || [] ).map( ( b ) => ( { label: b.name, url: b.url } ) ) ) + '</div></div>';
	}
	const itemHtml = ( p ) => {
		const sv = ( p.extensions && p.extensions.sv ) || {};
		return '<a class="sv-suggest__item" href="' + esc( p.permalink ) + '">' + ( p.images[ 0 ] ? '<img src="' + esc( p.images[ 0 ].thumbnail ) + '" alt="">' : '' ) + '<span>' + p.name + '<small>' + esc( sv.size || '' ) + ( p.is_in_stock ? ' · ' + fmt( money( p.prices.price, p.prices ) ) : ' · Sold' ) + '</small></span></a>';
	};
	function initSearch() {
		$$( '.sv-search input[type="search"]' ).forEach( ( input ) => {
			const form = input.closest( 'form' );
			const list = document.createElement( 'div' );
			list.className = 'sv-suggest';
			list.hidden = true;
			form.style.position = 'relative';
			form.appendChild( list );
			let timer;
			let seq = 0;
			input.setAttribute( 'autocomplete', 'off' );
			const run = () => {
				clearTimeout( timer );
				const q = input.value.trim();
				if ( q.length < 2 ) {
					list.innerHTML = quickHtml();
					list.hidden = false;
					return;
				}
				timer = setTimeout( async () => {
					const mine = ++seq;
					try {
						const size = sizeQuery( q );
						const slug = size ? size.name.toLowerCase().replace( ' ', '-' ).replace( '.', '-' ) : '';
						const url = size && size.url
							? cfg.store + 'products?per_page=6&attributes[0][attribute]=pa_size&attributes[0][slug]=' + encodeURIComponent( slug )
							: cfg.store + 'products?search=' + encodeURIComponent( q ) + '&per_page=6';
						const items = await ( await fetch( url ) ).json();
						if ( mine !== seq ) return;
						const more = size && size.url ? '<a class="sv-chip" href="' + esc( size.url ) + '">All pairs in ' + esc( size.name ) + ' →</a>' : '<button type="submit">See all results for “' + esc( q ) + '”</button>';
						list.innerHTML = items.length
							? items.map( itemHtml ).join( '' ) + more
							: '<p>Nothing matches “' + esc( q ) + '” right now. <a href="' + esc( waUrl( 'Hi Shoevenir, do you have ' + q + '?' ) ) + '">Ask us on WhatsApp</a> – new bales land every week.</p>';
						list.hidden = false;
					} catch ( e ) {}
				}, 180 );
			};
			input.addEventListener( 'input', run );
			input.addEventListener( 'focus', run );
			document.addEventListener( 'click', ( e ) => {
				if ( ! form.contains( e.target ) ) list.hidden = true;
			} );
			input.addEventListener( 'keydown', ( e ) => {
				if ( e.key === 'Escape' ) list.hidden = true;
			} );
		} );
	}

	// Search icon (narrower screens) opens the search row.
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-sv-search-open]' );
		if ( ! b ) return;
		const header = b.closest( '.sv-header' );
		const open = ! header.classList.contains( 'is-searching' );
		header.classList.toggle( 'is-searching', open );
		b.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
		const input = header.querySelector( '.sv-search input[type="search"]' );
		if ( open && input ) input.focus();
	} );

	/* Size bar: in-stock toggle ------------------------------------------ */
	function initSizebar() {
		$$( '[data-sv-sizebar]' ).forEach( ( bar ) => {
			const box = bar.querySelector( '[data-sv-instock-toggle]' );
			if ( ! box || box.dataset.svOn ) return;
			box.dataset.svOn = '1';
			const apply = () => {
				bar.classList.toggle( 'is-instock', box.checked );
				$$( '.sv-size', bar ).forEach( ( a ) => {
					const u = new URL( a.href, location.href );
					if ( box.checked ) u.searchParams.set( 'instock', '1' );
					else u.searchParams.delete( 'instock' );
					a.href = u.toString();
				} );
			};
			box.addEventListener( 'change', () => {
				apply();
				toast( box.checked ? 'Showing sizes with pairs in stock' : 'Showing every size, EU 38 – 46' );
			} );
			apply();
		} );
	}

	/* Free-delivery bar ------------------------------------------------- */
	function renderBar( total ) {
		const left = Math.max( 0, freeAt - total );
		const pct = Math.min( 100, Math.round( ( total / freeAt ) * 100 ) );
		const msg = left > 0
			? 'Add <strong>' + fmt( left ) + '</strong> more for <strong>free Nairobi Express shipping!</strong>'
			: "<strong>You've unlocked free Nairobi Express shipping!</strong>";
		$$( '[data-sv-freebar]' ).forEach( ( el ) => {
			el.innerHTML = msg + '<div class="sv-freebar__track"><div class="sv-freebar__fill" style="width:' + pct + '%"></div></div>';
		} );
	}
	// The cart page and the mini cart change quantities without a reload; follow them.
	function watchCart() {
		const data = window.wp && window.wp.data;
		if ( ! data || ! data.select( 'wc/store/cart' ) ) return;
		let last = null;
		data.subscribe( () => {
			const totals = data.select( 'wc/store/cart' ).getCartTotals();
			if ( totals && totals.total_items !== undefined ) {
				const sub = money( totals.total_items, totals );
				if ( sub !== last ) {
					last = sub;
					renderBar( sub );
				}
			}
		} );
	}

	/* Checkout steps ---------------------------------------------------- */
	// Light up the step the customer is working on.
	const STEP = [ [ 'contact', 0 ], [ 'shipping-fields', 1 ], [ 'billing-fields', 1 ], [ 'shipping-method', 1 ], [ 'pickup', 2 ], [ 'shipping-option', 2 ], [ 'payment', 3 ] ];
	document.addEventListener( 'focusin', ( e ) => {
		const step = e.target.closest( '.wc-block-components-checkout-step' );
		const bar = document.querySelector( '.sv-steps:not(.sv-steps--done)' );
		if ( ! step || ! bar ) return;
		const hit = STEP.find( ( [ k ] ) => ( step.id + ' ' + step.className ).includes( k ) );
		if ( ! hit ) return;
		$$( 'li', bar ).forEach( ( li, i ) => li.classList.toggle( 'is-on', i <= hit[ 1 ] ) );
	} );

	function init() {
		paintWish();
		renderWishlist();
		initSearch();
		initPairs();
		initSizebar();
		watchCart();
		// Cards and the mini cart re-render client-side; keep hearts and pair buttons in sync.
		new MutationObserver( () => {
			paintWish();
			initPairs();
		} ).observe( document.body, { childList: true, subtree: true } );
	}
	if ( document.readyState === 'loading' ) document.addEventListener( 'DOMContentLoaded', init );
	else init();
} )();
