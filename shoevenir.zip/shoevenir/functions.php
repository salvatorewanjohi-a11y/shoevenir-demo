<?php
/**
 * Shoevenir child theme.
 */

const SV_WHATSAPP      = '254725533917';
const SV_PHONE         = '0725 533 917';
const SV_COMMUNITY     = 'https://chat.whatsapp.com/INpL9SxZ1raBMFNVQkuQLO';
const SV_INSTAGRAM     = 'https://www.instagram.com/_shoevenir_/';
const SV_FREE_DELIVERY = 10000; // PLACEHOLDER: free Nairobi Express rider from this cart value (matches the shipping zone in setup.php).
const SV_FONTS         = 'https://fonts.googleapis.com/css2?family=Anton&family=Inter:wght@400;500;600;700;800&display=swap';

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	$uri = get_stylesheet_directory_uri();
	wp_enqueue_style( 'sv-fonts', SV_FONTS, [], null );
	wp_enqueue_style( 'sv', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'sv', $uri . '/assets/sv.js', [], filemtime( $dir . '/assets/sv.js' ), true );
	wp_localize_script( 'sv', 'SV', [
		'store'  => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'shop'   => esc_url_raw( wc_get_page_permalink( 'shop' ) ),
		'home'   => esc_url_raw( home_url( '/' ) ),
		'wa'     => SV_WHATSAPP,
		'freeAt' => SV_FREE_DELIVERY,
		'sizes'  => array_map( fn( $t ) => [ 'name' => $t->name, 'url' => get_term_link( $t ), 'n' => $t->count ], sv_size_terms() ),
		'brands' => array_map( fn( $t ) => [ 'name' => $t->name, 'url' => get_term_link( $t ) ], sv_brands() ),
	] );
} );

add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style( 'sv-fonts', SV_FONTS, [], null );
} );
add_action( 'after_setup_theme', function () {
	add_editor_style( 'style.css' );
} );

// Size and grade pages (/size/eu-43/) need rewrite rules made after the attributes exist.
add_action( 'init', function () {
	if ( get_option( 'sv_rewrites' ) !== '1' && taxonomy_exists( 'pa_size' ) ) {
		flush_rewrite_rules();
		update_option( 'sv_rewrites', '1' );
	}
}, 99 );

// WooCommerce's symbol for Kenyan shillings is "KSh", the way shops here write it.
add_filter( 'woocommerce_currency_symbol', fn( $s, $c ) => $c === 'KES' ? 'KSh' : $s, 10, 2 );

function sv_wa_link( $text = '' ) {
	return 'https://wa.me/' . SV_WHATSAPP . ( $text !== '' ? '?text=' . rawurlencode( $text ) : '' );
}

function sv_money( $amount ) {
	return 'KSh ' . number_format( (float) $amount );
}

/* -------------------------------------------------------------------------
 * Shoe facts: size, grade, condition, retail price
 * ---------------------------------------------------------------------- */

function sv_parent( WC_Product $product ) {
	return $product->is_type( 'variation' ) ? wc_get_product( $product->get_parent_id() ) : $product;
}

/** EU size names on the product ("EU 43"), smallest first. */
function sv_sizes( WC_Product $product ) {
	$names = wc_get_product_terms( sv_parent( $product )->get_id(), 'pa_size', [ 'fields' => 'names' ] );
	usort( $names, fn( $a, $b ) => (float) substr( $a, 3 ) <=> (float) substr( $b, 3 ) );
	return $names;
}

function sv_grade( WC_Product $product ) {
	$names = wc_get_product_terms( sv_parent( $product )->get_id(), 'pa_grade', [ 'fields' => 'names' ] );
	return $names[0] ?? '';
}

function sv_grade_slug( WC_Product $product ) {
	$slugs = wc_get_product_terms( sv_parent( $product )->get_id(), 'pa_grade', [ 'fields' => 'slugs' ] );
	return $slugs[0] ?? '';
}

/** "EU 43 · UK 8.5" for a single pair, "EU 42.5, 43 & 44.5" for a multi-pair listing. */
function sv_size_label( WC_Product $product ) {
	// A pair picked from a multi-pair listing: its own size ("… – EU 43") and UK size.
	if ( $product->is_type( 'variation' ) && preg_match( '/EU ([\d.]+)$/', implode( ' ', $product->get_attributes() ), $m ) ) {
		$uk = $product->get_meta( '_sv_uk' );
		return 'EU ' . $m[1] . ( $uk !== '' ? ' · UK ' . $uk : '' );
	}
	$sizes = sv_sizes( $product );
	if ( ! $sizes ) {
		return '';
	}
	if ( count( $sizes ) === 1 ) {
		$uk = get_post_meta( $product->get_id(), '_sv_uk', true );
		return $sizes[0] . ( $uk !== '' ? ' · UK ' . $uk : '' );
	}
	$nums = array_map( fn( $s ) => substr( $s, 3 ), $sizes );
	$last = array_pop( $nums );
	return 'EU ' . implode( ', ', $nums ) . ' & ' . $last;
}

/** Condition scores out of 10, from the "Label: score" lines staff type on the product screen. */
function sv_condition( $product_id ) {
	$out = [];
	foreach ( preg_split( '/\R/', (string) get_post_meta( $product_id, '_sv_condition', true ) ) as $line ) {
		$parts = array_map( 'trim', explode( ':', $line, 2 ) );
		if ( count( $parts ) === 2 && $parts[0] !== '' && is_numeric( $parts[1] ) ) {
			$out[ $parts[0] ] = max( 0, min( 10, (float) $parts[1] ) );
		}
	}
	return $out;
}

const SV_CONDITION_HINTS = [
	'Sole'        => 'Tread and heel wear',
	'Upper'       => 'Leather, suede or canvas',
	'Cleanliness' => 'Washed and restored',
	'Insole'      => 'Footbed and lining',
];

function sv_condition_html( $product_id, $compact = false ) {
	$c = sv_condition( $product_id );
	if ( ! $c ) {
		return '';
	}
	$h = '<div class="sv-inspect' . ( $compact ? ' sv-inspect--compact' : '' ) . '">';
	foreach ( $c as $label => $score ) {
		$h .= '<div class="sv-inspect__row"><span class="sv-inspect__label">' . esc_html( $label ) . ( ! $compact && isset( SV_CONDITION_HINTS[ $label ] ) ? '<small>' . esc_html( SV_CONDITION_HINTS[ $label ] ) . '</small>' : '' ) . '</span><span class="sv-inspect__bar"><i style="width:' . ( $score * 10 ) . '%"></i></span><strong>' . esc_html( rtrim( rtrim( number_format( $score, 1 ), '0' ), '.' ) ) . '/10</strong></div>';
	}
	$avg = array_sum( $c ) / count( $c );
	return $h . '<p class="sv-inspect__total">Overall <strong>' . esc_html( number_format( $avg, 1 ) ) . '/10</strong></p></div>';
}

function sv_retail( WC_Product $product ) {
	return (float) get_post_meta( sv_parent( $product )->get_id(), '_sv_retail', true );
}

// UK retail price (new) struck through before our price, so buyers see the saving.
add_filter( 'woocommerce_get_price_html', function ( $html, $product ) {
	if ( is_admin() && ! wp_doing_ajax() ) {
		return $html;
	}
	$retail = sv_retail( $product );
	$price  = (float) $product->get_price();
	if ( $retail <= $price || $price <= 0 ) {
		return $html;
	}
	$save = round( ( 1 - $price / $retail ) * 100 );
	return '<span class="sv-retail" title="Price new in the UK">Retail <del>' . esc_html( sv_money( $retail ) ) . '</del></span> ' . $html . ' <span class="sv-save">−' . $save . '%</span>';
}, 20, 2 );

function sv_grade_badge( WC_Product $product ) {
	$g = sv_grade( $product );
	return $g ? '<span class="sv-grade sv-grade--' . esc_attr( sv_grade_slug( $product ) ) . '">' . esc_html( $g ) . '</span>' : '';
}

/** Pairs still available (a multi-pair listing counts each pair). */
function sv_pairs_left( WC_Product $product ) {
	if ( $product->is_type( 'variable' ) ) {
		$n = 0;
		foreach ( $product->get_children() as $vid ) {
			$v = wc_get_product( $vid );
			if ( $v && $v->is_in_stock() ) {
				$n += $v->managing_stock() ? max( 0, (int) $v->get_stock_quantity() ) : 1;
			}
		}
		return $n;
	}
	return $product->is_in_stock() ? ( $product->managing_stock() ? max( 0, (int) $product->get_stock_quantity() ) : 1 ) : 0;
}

add_filter( 'woocommerce_product_single_add_to_cart_text', fn() => 'Add to cart' );
add_filter( 'woocommerce_product_add_to_cart_text', function ( $t, $p ) {
	if ( ! $p || ! $p->is_in_stock() ) {
		return 'Sold';
	}
	return $p->is_type( 'variable' ) ? 'Choose your pair' : 'Add to cart';
}, 10, 2 );
add_filter( 'woocommerce_get_availability_text', function ( $text, $product ) {
	if ( ! $product->is_in_stock() ) {
		return 'Sold – this pair has gone';
	}
	return 'One pair only · in Nairobi, ready to ship';
}, 10, 2 );

/* -------------------------------------------------------------------------
 * Product page
 * ---------------------------------------------------------------------- */

// Size, grade and condition above the add-to-cart button.
add_action( 'woocommerce_before_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$brand = taxonomy_exists( 'product_brand' ) ? wp_get_post_terms( $product->get_id(), 'product_brand', [ 'fields' => 'names' ] ) : [];
	echo '<ul class="sv-facts">';
	echo '<li><span>Size</span><strong>' . esc_html( sv_size_label( $product ) ) . '</strong></li>';
	echo '<li><span>Condition</span><strong>' . esc_html( sv_grade( $product ) ) . '</strong></li>';
	if ( $brand && ! is_wp_error( $brand ) ) {
		echo '<li><span>Brand</span><strong>' . esc_html( $brand[0] ) . '</strong></li>';
	}
	echo '<li><span>Stock</span><strong>' . ( $product->is_in_stock() ? 'One of one' : 'Sold' ) . '</strong></li>';
	echo '</ul>';
	echo '<p class="sv-size-help"><a href="#tab-title-sv_size" data-sv-tab="sv_size">Size guide: UK / EU / US →</a></p>';
	$c = sv_condition_html( $product->get_id(), true );
	if ( $c ) {
		echo '<div class="sv-inspect-wrap"><p class="sv-mini-label">Condition inspector</p>' . $c . '</div>';
	}
} );

// Order on WhatsApp and buying promises under the add-to-cart button.
add_action( 'woocommerce_after_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$size = sv_size_label( $product );
	$msg  = 'Hi Shoevenir, is the ' . $product->get_name() . ' (' . $size . ', ' . sv_money( $product->get_price() ) . ') still available? ' . $product->get_permalink();
	echo '<a class="sv-wa-order" data-sv-wa-product="' . esc_attr( $product->get_name() ) . '" data-sv-wa-price="' . esc_attr( sv_money( $product->get_price() ) ) . '" data-sv-wa-size="' . esc_attr( $size ) . '" data-sv-wa-url="' . esc_url( $product->get_permalink() ) . '" href="' . esc_url( sv_wa_link( $msg ) ) . '" target="_blank" rel="noopener">' . SV_WA_ICON . 'Order via WhatsApp</a>';

	echo '<div class="sv-promise"><div><span aria-hidden="true">✓</span><p><strong>Authentic Ex-UK, handpicked</strong>Checked, cleaned and photographed pair by pair: what you see is the exact pair you get.</p></div><div><span aria-hidden="true">⚡</span><p><strong>Same-day Nairobi Express</strong>Free over ' . esc_html( sv_money( SV_FREE_DELIVERY ) ) . '. Countrywide courier in 1–2 days, DHL worldwide.</p></div><div><span aria-hidden="true">✆</span><p><strong>Want a video first?</strong>WhatsApp us and we\'ll send a live video of this pair.</p></div></div>';
} );

// Condition, size guide, authenticity, care and shipping tabs.
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	global $product;
	if ( ! $product ) {
		return $tabs;
	}
	$pid = $product->get_id();
	$tabs['sv_condition'] = [
		'title'    => 'Condition report',
		'priority' => 5,
		'callback' => function () use ( $product, $pid ) {
			echo '<div class="sv-report"><div>' . wp_kses_post( wpautop( $product->get_description() ) ) . '<p class="sv-report__grade">' . sv_grade_badge( $product ) . '</p><p class="sv-small">Every pair is graded by hand before it\'s listed. Scores are out of 10, where 10 is as new. The photos are of this exact pair, sole and insole included.</p></div>' . sv_condition_html( $pid ) . '</div>';
		},
	];
	$tabs['sv_size'] = [
		'title'    => 'Size guide',
		'priority' => 10,
		'callback' => 'sv_size_guide',
	];
	$tabs['sv_auth'] = [
		'title'    => 'Authenticity guarantee',
		'priority' => 15,
		'callback' => function () {
			echo '<ul><li><strong>Ex-UK stock:</strong> our pairs come in UK bales and are handpicked one by one. We only list originals.</li><li><strong>Checked before listing:</strong> size tag, stitching, logos, insole print and sole pattern are checked on every pair.</li><li><strong>Check it yourself:</strong> with cash on delivery or pick-up you inspect the pair before you pay. Ask on WhatsApp for close-ups of the size tag or any detail.</li><li><strong>If it isn\'t as described</strong> (wrong size, or condition worse than listed), tell us on handover and don\'t take it.</li></ul>';
		},
	];
	$tabs['sv_care'] = [
		'title'    => 'Care & cleaning',
		'priority' => 20,
		'callback' => function () {
			echo '<ul><li><strong>Leather:</strong> wipe with a damp cloth and a drop of mild soap, then dry in the shade. Never soak or machine-wash.</li><li><strong>Suede & nubuck:</strong> brush dry with a suede brush; a suede eraser lifts marks. Keep away from water and use a protector spray before the rains.</li><li><strong>Canvas (Converse, Vans):</strong> hand-wash with warm soapy water and an old toothbrush; stuff with paper and air-dry away from direct sun.</li><li><strong>Midsoles:</strong> a magic eraser or baking-soda paste brings white soles back.</li><li><strong>Shape & smell:</strong> use shoe trees or newspaper to hold the shape, and a little baking soda overnight to freshen.</li></ul>';
		},
	];
	$tabs['sv_shipping'] = [
		'title'    => 'Shipping',
		'priority' => 25,
		'callback' => function () {
			echo '<ul><li><strong>Nairobi Express rider:</strong> same-day delivery for KSh 300, free on orders over ' . esc_html( sv_money( SV_FREE_DELIVERY ) ) . '. Pay the rider cash or M-Pesa after checking the pair.</li><li><strong>Pick up in Nairobi CBD:</strong> free, Monday to Saturday 8 am – 7 pm. We send the spot on WhatsApp.</li><li><strong>Upcountry (all 47 counties):</strong> Wells Fargo or Fargo Courier in 1–2 days for KSh 450, or EasyCoach parcel for KSh 350, collected at the stage. Paid by M-Pesa before dispatch.</li><li><strong>International:</strong> DHL Worldwide Express in 3–7 working days from KSh 6,500. We confirm the exact cost for your country on WhatsApp before you pay.</li></ul>';
		},
	];
	unset( $tabs['description'], $tabs['additional_information'], $tabs['reviews'] );
	return $tabs;
}, 20 );

function sv_size_guide() {
	$rows = [ [ '5', '38', '6', '24' ], [ '6', '39', '7', '24.5' ], [ '6.5', '40', '7.5', '25' ], [ '7', '41', '8', '26' ], [ '8', '42', '9', '26.5' ], [ '8.5', '43', '9.5', '27.5' ], [ '9.5', '44', '10.5', '28' ], [ '10', '44.5', '11', '28.5' ], [ '10.5', '45.5', '11.5', '29' ], [ '11', '46', '12', '29.5' ] ];
	echo '<div class="sv-sizeguide"><table class="sv-size-table"><thead><tr><th>UK</th><th>EU</th><th>US men</th><th>Foot length (cm)</th></tr></thead><tbody>';
	foreach ( $rows as $r ) {
		echo '<tr><td>' . esc_html( $r[0] ) . '</td><td>' . esc_html( $r[1] ) . '</td><td>' . esc_html( $r[2] ) . '</td><td>' . esc_html( $r[3] ) . '</td></tr>';
	}
	echo '</tbody></table><div class="sv-small"><p><strong>How to measure:</strong> stand on a sheet of paper, mark your heel and longest toe, and measure the gap in cm. Pick the size whose foot length is the same or just over.</p><p>Sizes run slightly differently by brand (a UK 8.5 Nike is an EU 43, an adidas UK 8.5 is EU 42⅔), so every listing shows the size printed on that pair\'s own tag. US women\'s is about 1.5 sizes above US men\'s. Between sizes? WhatsApp us your usual size in another brand and we\'ll advise.</p></div></div>';
}

// "Style with this": pairs from other categories, in place of WooCommerce's related products
// (an older related-products block, or a product collection of the "related" kind).
add_filter( 'render_block_woocommerce/related-products', 'sv_pairing_html' );
add_filter( 'render_block_woocommerce/product-collection', function ( $content, $block ) {
	return ( $block['attrs']['collection'] ?? '' ) === 'woocommerce/product-collection/related' ? sv_pairing_html() : $content;
}, 10, 2 );
function sv_pairing_html() {
	$product = is_singular( 'product' ) ? wc_get_product( get_queried_object_id() ) : null;
	if ( ! $product instanceof WC_Product ) {
		return '';
	}
	$cats  = $product->get_category_ids();
	$picks = wc_get_products( [ 'status' => 'publish', 'limit' => 12, 'exclude' => [ $product->get_id() ], 'stock_status' => 'instock', 'orderby' => 'rand' ] );
	usort( $picks, fn( $a, $b ) => count( array_intersect( $a->get_category_ids(), $cats ) ) <=> count( array_intersect( $b->get_category_ids(), $cats ) ) );
	$picks = array_slice( $picks, 0, 4 );
	if ( ! $picks ) {
		return '';
	}
	$h = '<section class="sv-pairing"><div class="sv-head"><div><p class="sv-eyebrow">Pairing suggestions</p><h2>Style with this</h2></div><a class="sv-more" href="' . esc_url( wc_get_page_permalink( 'shop' ) ) . '">All shoes →</a></div><div class="sv-mini-grid">';
	foreach ( $picks as $p ) {
		$h .= sv_mini_card( $p );
	}
	return $h . '</div></section>';
}

function sv_mini_card( WC_Product $p ) {
	return '<a class="sv-mini" href="' . esc_url( $p->get_permalink() ) . '"><span class="sv-mini__img">' . $p->get_image( 'woocommerce_thumbnail', [ 'loading' => 'lazy', 'alt' => '' ] ) . '<em>' . esc_html( sv_size_label( $p ) ) . '</em></span><strong>' . esc_html( $p->get_name() ) . '</strong><span class="sv-mini__price">' . esc_html( sv_money( $p->get_price() ) ) . '</span></a>';
}

/* -------------------------------------------------------------------------
 * Product cards
 * ---------------------------------------------------------------------- */

function sv_card_product( $instance ) {
	$id = $instance->context['postId'] ?? get_the_ID();
	return $id && ! is_admin() ? wc_get_product( $id ) : null;
}

const SV_HEART   = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.3 4.6 13a4.8 4.8 0 0 1 6.8-6.8l.6.6.6-.6a4.8 4.8 0 0 1 6.8 6.8Z"/></svg>';
const SV_WA_ICON = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm5.3 14.2c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-3.9-4.7-4.1-.1-.2-1.1-1.5-1.1-2.9s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.3 0 .5l-.4.6-.4.4c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.3 2.4 1.5.3.1.5.1.7-.1l.9-1.1c.2-.3.4-.2.7-.1l1.9.9c.3.1.5.2.5.3.1.2.1.7-.1 1.2Z"/></svg>';

// Hover photo, grade badge, size tag, wishlist heart and quick view on product images.
add_filter( 'render_block_woocommerce/product-image', function ( $content, $block, $instance ) {
	$product = sv_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$gallery = $product->get_gallery_image_ids();
	if ( $gallery ) {
		$alt = wp_get_attachment_image( $gallery[0], 'woocommerce_thumbnail', false, [ 'class' => 'sv-alt-img', 'alt' => '', 'loading' => 'lazy' ] );
		$content = preg_replace( '#(<img[^>]*>)#', '$1' . $alt, $content, 1 );
	}
	$sold  = $product->is_in_stock() ? '' : '<span class="sv-sold">Sold</span>';
	$extra = sprintf(
		'<span class="sv-tags">%4$s</span>%5$s<span class="sv-size-tag">%6$s</span><button type="button" class="sv-heart" data-sv-wish="%1$d" aria-label="Save %2$s to your wishlist" aria-pressed="false">%3$s</button><button type="button" class="sv-qv-btn" data-sv-qv="%1$d" aria-label="Quick view of %2$s">Quick view</button>',
		$product->get_id(),
		esc_attr( $product->get_name() ),
		SV_HEART,
		sv_grade_badge( $product ),
		$sold,
		esc_html( sv_size_label( $product ) )
	);
	$pos = strrpos( $content, '</div>' );
	return $pos === false ? $content : substr_replace( $content, $extra . '</div>', $pos, 6 );
}, 10, 3 );

// Brand above the title.
add_filter( 'render_block_core/post-title', function ( $content, $block, $instance ) {
	if ( empty( $block['attrs']['__woocommerceNamespace'] ) ) {
		return $content;
	}
	$product = sv_card_product( $instance );
	$brands  = $product && taxonomy_exists( 'product_brand' ) ? wp_get_post_terms( $product->get_id(), 'product_brand', [ 'fields' => 'names' ] ) : [];
	return ( $brands && ! is_wp_error( $brands ) ? '<p class="sv-card-brand">' . esc_html( $brands[0] ) . '</p>' : '' ) . $content;
}, 10, 3 );

// Simple (single-pair) products add to the cart from the card without leaving the page.
add_filter( 'render_block_woocommerce/product-button', function ( $content, $block, $instance ) {
	$product = sv_card_product( $instance );
	if ( ! $product || ! $product->is_in_stock() || ! $product->is_type( 'simple' ) ) {
		return $content;
	}
	return '<div class="wp-block-button wc-block-components-product-button"><button type="button" class="wp-block-button__link wp-element-button sv-quick-add" data-sv-add="' . $product->get_id() . '" data-sv-name="' . esc_attr( $product->get_name() ) . '">Add to cart</button></div>';
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Brands, sizes, filters
 * ---------------------------------------------------------------------- */

function sv_categories() {
	$terms = get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => [ (int) get_option( 'default_product_cat' ) ], 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

function sv_brands() {
	if ( ! taxonomy_exists( 'product_brand' ) ) {
		return [];
	}
	$terms = get_terms( [ 'taxonomy' => 'product_brand', 'hide_empty' => true ] );
	if ( is_wp_error( $terms ) ) {
		return [];
	}
	usort( $terms, fn( $a, $b ) => $b->count <=> $a->count ?: strcasecmp( $a->name, $b->name ) );
	return $terms;
}

function sv_size_terms( $hide_empty = true ) {
	if ( ! taxonomy_exists( 'pa_size' ) ) {
		return [];
	}
	$terms = get_terms( [ 'taxonomy' => 'pa_size', 'hide_empty' => $hide_empty ] );
	if ( is_wp_error( $terms ) ) {
		return [];
	}
	usort( $terms, fn( $a, $b ) => (float) substr( $a->name, 3 ) <=> (float) substr( $b->name, 3 ) );
	return $terms;
}

function sv_grade_terms() {
	if ( ! taxonomy_exists( 'pa_grade' ) ) {
		return [];
	}
	$terms = get_terms( [ 'taxonomy' => 'pa_grade', 'hide_empty' => true, 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

/** Pairs in stock in each size (a size page lists sold pairs too, so count separately). */
function sv_size_stock() {
	$out = [];
	foreach ( wc_get_products( [ 'status' => 'publish', 'limit' => -1 ] ) as $p ) {
		if ( $p->is_type( 'variable' ) ) {
			foreach ( $p->get_children() as $vid ) {
				$v = wc_get_product( $vid );
				if ( $v && $v->is_in_stock() && preg_match( '/EU ([\d.]+)$/', implode( ' ', $v->get_attributes() ), $m ) ) {
					$out[ 'EU ' . $m[1] ] = ( $out[ 'EU ' . $m[1] ] ?? 0 ) + 1;
				}
			}
		} elseif ( $p->is_in_stock() ) {
			foreach ( sv_sizes( $p ) as $s ) {
				$out[ $s ] = ( $out[ $s ] ?? 0 ) + 1;
			}
		}
	}
	return $out;
}

// "Shop by brand & style": one photo tile per brand.
add_shortcode( 'sv_brand_tiles', function () {
	$h    = '<div class="sv-brandtiles">';
	$used = [];
	foreach ( array_slice( sv_brands(), 0, 8 ) as $t ) {
		$list = wc_get_products( [ 'status' => 'publish', 'limit' => 6, 'orderby' => 'menu_order', 'order' => 'ASC', 'tax_query' => [ [ 'taxonomy' => 'product_brand', 'terms' => $t->term_id ] ] ] );
		$pick = current( array_filter( $list, fn( $p ) => ! in_array( $p->get_id(), $used, true ) ) ) ?: ( $list[0] ?? null );
		$used[] = $pick ? $pick->get_id() : 0;
		$h .= sprintf(
			'<a class="sv-brandtile" href="%s"><span class="sv-brandtile__img">%s</span><span class="sv-brandtile__txt"><strong>%s</strong><em>%s</em></span></a>',
			esc_url( get_term_link( $t ) ),
			$pick ? $pick->get_image( 'woocommerce_thumbnail', [ 'loading' => 'lazy', 'alt' => '' ] ) : '',
			esc_html( $t->name ),
			esc_html( sprintf( _n( '%d pair', '%d pairs', $t->count ), $t->count ) )
		);
	}
	return $h . '</div>';
} );

// Category chips under the brand tiles.
add_shortcode( 'sv_style_chips', function () {
	$h = '<div class="sv-chiprow"><span>Shop by style</span>';
	foreach ( sv_categories() as $t ) {
		$h .= sv_chip( $t->name, get_term_link( $t ), false, $t->count );
	}
	return $h . '</div>';
} );

// Popular sizes EU 38–46, with how many pairs are in stock in each.
add_shortcode( 'sv_sizebar', function () {
	$stock = sv_size_stock();
	$terms = sv_size_terms( false );
	$h     = '<div class="sv-sizebar" data-sv-sizebar><div class="sv-sizebar__top"><p><strong>Find your size</strong> EU 38 – 46 · UK 5 – 11</p><label class="sv-toggle"><input type="checkbox" data-sv-instock-toggle checked> <span>Only sizes in stock</span></label></div><div class="sv-sizebar__sizes">';
	foreach ( $terms as $t ) {
		$n   = $stock[ $t->name ] ?? 0;
		$uk  = [ '38' => '5', '39' => '6', '40' => '6.5', '41' => '7', '42' => '8', '42.5' => '8', '43' => '8.5', '44' => '9.5', '44.5' => '10', '45' => '10.5', '45.5' => '10.5', '46' => '11' ][ substr( $t->name, 3 ) ] ?? '';
		$url = add_query_arg( 'instock', '1', get_term_link( $t ) );
		$h  .= '<a class="sv-size' . ( $n ? '' : ' is-empty' ) . '" href="' . esc_url( $url ) . '" data-n="' . $n . '"><strong>' . esc_html( substr( $t->name, 3 ) ) . '</strong><small>UK ' . esc_html( $uk ) . '</small><em>' . ( $n ? $n . ' ' . _n( 'pair', 'pairs', $n ) : 'none now' ) . '</em></a>';
	}
	return $h . '</div></div>';
} );

function sv_chip( $label, $url, $on, $count = null, $small = false ) {
	return sprintf( '<a class="sv-chip%s%s" href="%s">%s%s</a>', $small ? ' sv-chip--sm' : '', $on ? ' is-on' : '', esc_url( $url ), esc_html( $label ), $count === null ? '' : ' <em>' . (int) $count . '</em>' );
}

// Style, brand, size and grade chips above shop, category, brand, size and search pages.
add_shortcode( 'sv_filters', function () {
	$current = get_queried_object();
	$cur_id  = $current instanceof WP_Term ? $current->term_id : 0;
	$instock = ! empty( $_GET['instock'] );
	$keep    = fn( $url ) => $instock ? add_query_arg( 'instock', '1', $url ) : $url;
	$h = '<nav class="sv-filters" aria-label="Filter shoes"><div class="sv-filters__row"><span>Style</span>';
	$h .= sv_chip( 'All shoes', $keep( wc_get_page_permalink( 'shop' ) ), is_shop() );
	foreach ( sv_categories() as $t ) {
		$h .= sv_chip( $t->name, $keep( get_term_link( $t ) ), $t->term_id === $cur_id, $t->count );
	}
	$h .= '</div><div class="sv-filters__row"><span>Brand</span>';
	foreach ( sv_brands() as $t ) {
		$h .= sv_chip( $t->name, $keep( get_term_link( $t ) ), $t->term_id === $cur_id, null, true );
	}
	$h .= '</div><div class="sv-filters__row"><span>Size (EU)</span>';
	foreach ( sv_size_terms() as $t ) {
		$h .= sv_chip( substr( $t->name, 3 ), $keep( get_term_link( $t ) ), $t->term_id === $cur_id, null, true );
	}
	$h .= '</div><div class="sv-filters__row"><span>Grade</span>';
	foreach ( sv_grade_terms() as $t ) {
		$h .= sv_chip( $t->name, $keep( get_term_link( $t ) ), $t->term_id === $cur_id, null, true );
	}
	$here = remove_query_arg( [ 'instock', 'paged' ] );
	$h .= '<a class="sv-toggle sv-toggle--link' . ( $instock ? ' is-on' : '' ) . '" href="' . esc_url( $instock ? $here : add_query_arg( 'instock', '1', $here ) ) . '"><i></i>Hide sold pairs</a>';
	return $h . '</div></nav>';
} );

// ?instock=1 hides sold pairs on shop, category, brand and size pages.
add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() || ! $q->is_main_query() || empty( $_GET['instock'] ) ) {
		return;
	}
	if ( $q->is_post_type_archive( 'product' ) || $q->is_tax( get_object_taxonomies( 'product' ) ) || ( $q->is_search() && ( $q->get( 'post_type' ) === 'product' ) ) ) {
		$meta   = (array) $q->get( 'meta_query' );
		$meta[] = [ 'key' => '_stock_status', 'value' => 'instock' ];
		$q->set( 'meta_query', $meta );
	}
} );

// Size and grade pages are titled by the term alone ("EU 43").
add_filter( 'get_the_archive_title', function ( $title ) {
	if ( is_tax( 'pa_size' ) ) {
		return 'Size ' . single_term_title( '', false );
	}
	return is_tax( 'pa_grade' ) ? single_term_title( '', false ) : $title;
} );

add_shortcode( 'sv_wishlist', function () {
	return '<div class="sv-wishlist" data-sv-wishlist><p class="sv-small">Loading your saved pairs…</p></div>';
} );

// Quick view pop-up, filled in by sv.js.
add_action( 'wp_footer', function () {
	echo '<dialog id="sv-qv" class="sv-dialog sv-qv" aria-label="Quick view"><form method="dialog"><button class="sv-dialog__close" aria-label="Close">×</button></form><div data-sv-qv-body></div></dialog>';
} );

// Size, grade, condition and UK size for the quick view (Store API).
// (woocommerce_blocks_loaded fires before the theme loads, so register on init.)
add_action( 'init', function () {
	if ( ! function_exists( 'woocommerce_store_api_register_endpoint_data' ) ) {
		return;
	}
	woocommerce_store_api_register_endpoint_data( [
		'endpoint'        => \Automattic\WooCommerce\StoreApi\Schemas\V1\ProductSchema::IDENTIFIER,
		'namespace'       => 'sv',
		'data_callback'   => function ( $product ) {
			return [
				'size'      => sv_size_label( $product ),
				'grade'     => sv_grade( $product ),
				'gradeSlug' => sv_grade_slug( $product ),
				'condition' => sv_condition_html( sv_parent( $product )->get_id(), true ),
			];
		},
		'schema_callback' => fn() => [],
		'schema_type'     => ARRAY_A,
	] );
	// Cart items carry size and grade too, for the WhatsApp order message.
	woocommerce_store_api_register_endpoint_data( [
		'endpoint'        => \Automattic\WooCommerce\StoreApi\Schemas\V1\CartItemSchema::IDENTIFIER,
		'namespace'       => 'sv',
		'data_callback'   => function ( $item ) {
			$product = $item['data'] ?? null;
			return $product instanceof WC_Product ? [ 'size' => sv_size_label( $product ), 'grade' => sv_grade( $product ) ] : [];
		},
		'schema_callback' => fn() => [],
		'schema_type'     => ARRAY_A,
	] );
} );

/* -------------------------------------------------------------------------
 * Cart, checkout, order confirmation
 * ---------------------------------------------------------------------- */

function sv_freebar_html() {
	$total = WC()->cart ? (float) WC()->cart->get_displayed_subtotal() : 0;
	$left  = max( 0, SV_FREE_DELIVERY - $total );
	$pct   = min( 100, round( $total / SV_FREE_DELIVERY * 100 ) );
	$msg   = $left > 0
		? 'Add <strong>' . sv_money( $left ) . '</strong> more for <strong>free Nairobi Express shipping!</strong>'
		: '<strong>You\'ve unlocked free Nairobi Express shipping!</strong>';
	return '<div class="sv-freebar" data-sv-freebar>' . $msg . '<div class="sv-freebar__track"><div class="sv-freebar__fill" style="width:' . $pct . '%"></div></div></div>';
}
function sv_cart_note_html() {
	return '<div class="sv-cart-note"><strong>One of one.</strong> Each pair is unique and isn\'t held until you order, so check out before someone else does.</div>';
}
function sv_wa_cart_html() {
	return '<button type="button" class="sv-wa-cart" data-sv-wa-cart>' . SV_WA_ICON . 'Order this cart on WhatsApp</button>';
}
add_filter( 'render_block_woocommerce/cart', fn( $c ) => sv_freebar_html() . sv_cart_note_html() . $c );
add_filter( 'render_block_woocommerce/proceed-to-checkout-block', fn( $c ) => $c . sv_wa_cart_html() );
add_filter( 'render_block_woocommerce/mini-cart-contents', function ( $c ) {
	return preg_replace( '#(<div[^>]*wp-block-woocommerce-mini-cart-items-block)#', sv_freebar_html() . '$1', $c, 1 );
} );
add_filter( 'render_block_woocommerce/mini-cart-footer-block', fn( $c ) => $c . '<div class="sv-wa-cart-wrap">' . sv_wa_cart_html() . '</div>' );

// Checkout steps across the top.
add_filter( 'render_block_woocommerce/checkout', function ( $c ) {
	$steps = [ 'Your details', 'Delivery destination', 'Courier', 'Payment', 'Confirmation' ];
	$h = '<ol class="sv-steps" aria-label="Checkout steps">';
	foreach ( $steps as $i => $s ) {
		$h .= '<li' . ( $i === 0 ? ' class="is-on"' : '' ) . '><b>' . ( $i + 1 ) . '</b><span>' . esc_html( $s ) . '</span></li>';
	}
	return $h . '</ol>' . $c;
} );

// A landmark helps the rider find the customer.
add_action( 'woocommerce_init', function () {
	if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
		return;
	}
	woocommerce_register_additional_checkout_field( [
		'id'       => 'sv/landmark',
		'label'    => 'Building, estate or nearest landmark',
		'location' => 'address',
		'type'     => 'text',
		'required' => false,
	] );
} );

// Tracking code and WhatsApp summary on the order confirmation page.
function sv_tracking_code( WC_Order $order ) {
	return 'SV-' . $order->get_order_number() . '-' . strtoupper( substr( $order->get_order_key(), -4 ) );
}
function sv_whatsapp_order_link( WC_Order $order ) {
	$lines = [ 'Hi Shoevenir, I just placed order ' . sv_tracking_code( $order ) . ':' ];
	foreach ( $order->get_items() as $item ) {
		$p       = $item->get_product();
		$name    = html_entity_decode( wp_strip_all_tags( $item->get_name() ), ENT_QUOTES, 'UTF-8' );
		// A pair from a multi-pair listing already names its size ("… – Red & white – EU 43").
		$lines[] = '• ' . $name . ( $p && ! $p->is_type( 'variation' ) ? ' (' . sv_size_label( $p ) . ', ' . sv_grade( $p ) . ')' : '' ) . ' – ' . sv_money( $item->get_total() );
	}
	$lines[] = 'Delivery: ' . $order->get_shipping_method() . ( (float) $order->get_shipping_total() > 0 ? ' (' . sv_money( $order->get_shipping_total() ) . ')' : '' );
	$lines[] = 'Total: ' . sv_money( $order->get_total() ) . ', ' . $order->get_payment_method_title();
	$address = trim( implode( ', ', array_filter( [ $order->get_shipping_address_1(), $order->get_shipping_city(), $order->get_shipping_country() !== 'KE' ? WC()->countries->countries[ $order->get_shipping_country() ] ?? '' : '' ] ) ) );
	if ( $address ) {
		$lines[] = 'Deliver to: ' . $address;
	}
	$lines[] = 'Name: ' . $order->get_formatted_billing_full_name() . ', ' . $order->get_billing_phone();
	return sv_wa_link( implode( "\n", $lines ) );
}
add_filter( 'render_block_woocommerce/order-confirmation-status', function ( $content ) {
	$order_id = absint( get_query_var( 'order-received' ) );
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order || ! hash_equals( $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ?? '' ) ) ) ) {
		return $content;
	}
	$next = $order->get_payment_method() === 'cheque'
		? 'Watch your phone: we\'re confirming your pair and will send an M-Pesa prompt to ' . esc_html( $order->get_billing_phone() ) . '.'
		: 'We\'ll call or WhatsApp you shortly to confirm your pair and arrange delivery or pick-up.';
	return $content . '<div class="sv-thanks"><ol class="sv-steps sv-steps--done"><li><b>✓</b><span>Details</span></li><li><b>✓</b><span>Destination</span></li><li><b>✓</b><span>Courier</span></li><li><b>✓</b><span>Payment</span></li><li class="is-on"><b>5</b><span>Confirmed</span></li></ol><p class="sv-thanks__code">Order tracking number <strong>' . esc_html( sv_tracking_code( $order ) ) . '</strong></p><p>' . $next . ' For the quickest reply, send your order summary to us on WhatsApp.</p><a class="wp-element-button sv-wa-btn" href="' . esc_attr( sv_whatsapp_order_link( $order ) ) . '" target="_blank" rel="noopener">' . SV_WA_ICON . 'Send order summary to WhatsApp</a></div>';
} );
add_action( 'woocommerce_admin_order_data_after_order_details', function ( $order ) {
	echo '<p class="form-field form-field-wide"><strong>Tracking number:</strong> ' . esc_html( sv_tracking_code( $order ) ) . '</p>';
} );

/* -------------------------------------------------------------------------
 * Staff product screen
 * ---------------------------------------------------------------------- */

add_action( 'woocommerce_product_options_general_product_data', function () {
	echo '<div class="options_group">';
	woocommerce_wp_text_input( [ 'id' => '_sv_retail', 'label' => 'UK retail price new (KSh)', 'type' => 'number', 'description' => 'Shown struck through next to your price, e.g. 18000. Leave empty to hide.', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_sv_uk', 'label' => 'UK size', 'description' => 'As printed on the size tag, e.g. 8.5. Set the EU size under Attributes → Size.', 'desc_tip' => true ] );
	woocommerce_wp_textarea_input( [ 'id' => '_sv_condition', 'label' => 'Condition scores', 'rows' => 4, 'placeholder' => "Sole: 9\nUpper: 9\nCleanliness: 10\nInsole: 9", 'description' => 'One per line, "Label: score out of 10". Shown as bars in the condition inspector.' ] );
	echo '<p class="form-field"><em>New pair: set Stock quantity to 1 (Inventory tab), add the EU size and the grade under Attributes, and the brand in the Brands box. When it sells, WooCommerce marks it Sold.</em></p></div>';
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	foreach ( [ '_sv_retail', '_sv_uk' ] as $k ) {
		if ( isset( $_POST[ $k ] ) ) {
			$product->update_meta_data( $k, sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) );
		}
	}
	if ( isset( $_POST['_sv_condition'] ) ) {
		$product->update_meta_data( '_sv_condition', sanitize_textarea_field( wp_unslash( $_POST['_sv_condition'] ) ) );
	}
} );

/* -------------------------------------------------------------------------
 * Housekeeping
 * ---------------------------------------------------------------------- */

// Kenyan addresses: no postcode, and we need a phone number to arrange delivery.
add_filter( 'woocommerce_get_country_locale', function ( $locale ) {
	$locale['KE']['postcode'] = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['city']     = [ 'label' => 'Area / Estate / Town (e.g. CBD, Westlands, Nakuru)' ];
	$locale['KE']['phone']    = [ 'required' => true ];
	return $locale;
} );

// Local preview only: the SQLite layer can't run WooCommerce's stock-reservation query.
// Real hosting uses MySQL, where this never triggers.
if ( isset( $GLOBALS['wpdb'] ) && stripos( get_class( $GLOBALS['wpdb'] ), 'sqlite' ) !== false ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}

// Browser tab icon.
add_action( 'wp_head', function () {
	if ( has_site_icon() ) {
		return;
	}
	$src = esc_url( get_stylesheet_directory_uri() . '/assets/icon.png' );
	echo "<link rel=\"icon\" href=\"$src\">\n<link rel=\"apple-touch-icon\" href=\"$src\">\n<meta name=\"theme-color\" content=\"#121212\">\n";
} );

// Templates use root-relative links ("/shop/"); point them at the real home URL so the site
// also works from a sub-folder (e.g. the WordPress Playground demo).
add_filter( 'render_block', function ( $content ) {
	$home = trailingslashit( home_url() );
	if ( $home === '/' || ! str_contains( $content, '="/' ) ) {
		return $content;
	}
	return preg_replace( '#\b(href|src)="/(?!/)#', '$1="' . $home, $content );
} );
